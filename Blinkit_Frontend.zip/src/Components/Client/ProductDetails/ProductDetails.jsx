import React from 'react'
import { Link } from 'react-router-dom'
import DetailCard from './DetailCard'
import ProductTitle from './ProductTitle'
import Navbar from '../ClientComponent/Navbar'
import Footer from '../ClientComponent/Footer'
import CartBtn from '../ClientComponent/CartBtn'

const ProductDetails = () => {
  return (
    <>
      <Navbar/>
      <div className='w-full md:px-20 px-5 mt-16 grid md:grid-cols-2 grid-cols-1'>
        <div className='w-full md:border-r mt-2 md:border-b-0'>
          <h2 className='font-medium text-xs cursor-pointer text-slate-600'><span className='hover:text-green-500'>Home</span> / <span className='hover:text-green-500'>Biscuit Gift Pack</span> / <span className='hover:text-green-500'>Parle Center Filled Biscuits (Choco, Milano Collection)</span></h2>
          <DetailCard/>
          <ProductTitle/>
        </div>
        <div className='w-full relative md:pl-10 md:pr-20 md:py-7 py-4 flex flex-col items-start '>
          
          <div className='w-full md:border-none border-t pt-3 md:pt-0'>
            <h1 className='font-semibold md:text-2xl text-xl'>Product Details</h1>
            <div className='w-full flex flex-col gap-3 mt-3 pr-4'>
              <div className='items flex flex-col'>
                <h1 className='md:font-medium font-bold text-sm'>Unit</h1>
                <h3 className='text-slate-500 font-normal text-sm'>250 g</h3>
              </div>
              <div className='items flex flex-col'>
                <h1 className='md:font-medium font-bold text-sm'>Shelf Life</h1>
                <h3 className='text-slate-500 font-normal text-sm'>8 months</h3>
              </div>
              <div className='items flex flex-col'>
                <h1 className='md:font-medium font-bold text-sm'>Country Of Origin</h1>
                <h3 className='text-slate-500 font-normal text-sm'>India</h3>
              </div>
              <div className='items flex flex-col'>
                <h1 className='md:font-medium font-bold text-sm'>FSSAI License</h1>
                <h3 className='text-slate-500 font-normal text-sm'>10013022002253</h3>
              </div>
              <div className='items flex flex-col'>
                <h1 className='md:font-medium font-bold text-sm'>Customer Care Details</h1>
                <h3 className='text-slate-500 font-normal text-sm'>Email: info@blinkit.com</h3>
              </div>
              <div className='items flex flex-col'>
                <h1 className='md:font-medium font-bold text-sm'>Return Policy</h1>
                <h3 className='text-slate-500 font-normal text-sm'>This Item is non-returnable. For a damaged, defective, incorrect or expired item, you can request a replacement within 72 hours of delivery. In case of an incorrect item, you may raise a replacement or return request only if the item is sealed/ unopened/ unused and in original condition</h3>
              </div>
              <div className='items flex flex-col'>
                <h1 className='md:font-medium font-bold text-sm'>Expiry Date</h1>
                <h3 className='text-slate-500 font-normal text-sm'>Please refer to the packaging of the product for expiry date.</h3>
              </div>
              <div className='items flex flex-col'>
                <h1 className='md:font-medium font-bold text-sm'>Net Weight</h1>
                <h3 className='text-slate-500 font-normal text-sm'>300 g</h3>
              </div>
              <div className='items flex flex-col'>
                <h1 className='md:font-medium font-bold text-sm'>Seller</h1>
                <h3 className='text-slate-500 font-normal text-sm'>TAMS GLOBAL PRIVATE LIMITED</h3>
              </div>
              <div className='items flex flex-col'>
                <h1 className='md:font-medium font-bold text-sm'>Seller FSSAI</h1>
                <h3 className='text-slate-500 font-normal text-sm'>13322001000621</h3>
              </div>
              <div className='items flex flex-col'>
                <h1 className='md:font-medium font-bold text-sm'>Description</h1>
                <h3 className='text-slate-500 font-normal text-sm'>Indulge yourself in the delectable taste of Parle Milano Centre Filled Choco Cookie. Each bite of this treat holds a sweet surprise of chocolate in between crisp chocolate biscuits, which makes this an absolute delight.</h3>
              </div>
              <div className='items flex flex-col'>
                <h1 className='md:font-medium font-bold text-sm'>Disclaimer</h1>
                <h3 className='text-slate-500 font-normal text-sm'>Every effort is made to maintain the accuracy of all information. However, actual product packaging and materials may contain more and/or different information. It is recommended not to solely rely on the information presented.</h3>
              </div>
              
              
              
            </div>
          </div>
        </div>

      </div>
      <CartBtn/>
      <Footer/>
    </>
  )
}

export default ProductDetails
