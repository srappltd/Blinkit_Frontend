import React from 'react'

const DetailCard = () => {
  return (
    <div className='w-full flex items-center md:mt-10 mt-2 flex-col border-b pb-10'>
          <div className='md:w-[60vh] md:h-[60vh] rounded md:rounded-none overflow-hidden'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=1080/app/images/products/sliding_image/409539a.jpg?ts=1706779675" className='w-full h-full object-cover' alt="" />
          </div>
          <div className='md:w-[80%] w-full h-[10vh] relative md:mt-5 mt-3' >
            <div className='h-full flex items-center gap-3 w-full overflow-x-auto py-1'>
              <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=85,metadata=none,w=120,h=120/app/images/products/sliding_image/409539g.jpg?ts=1706779675" className='h-full' alt="" />
              <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=85,metadata=none,w=120,h=120/app/images/products/sliding_image/409539g.jpg?ts=1706779675" className='h-full' alt="" />
              <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=85,metadata=none,w=120,h=120/app/images/products/sliding_image/409539g.jpg?ts=1706779675" className='h-full' alt="" />
              <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=85,metadata=none,w=120,h=120/app/images/products/sliding_image/409539g.jpg?ts=1706779675" className='h-full' alt="" />
              <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=85,metadata=none,w=120,h=120/app/images/products/sliding_image/409539g.jpg?ts=1706779675" className='h-full' alt="" />
              <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=85,metadata=none,w=120,h=120/app/images/products/sliding_image/409539g.jpg?ts=1706779675" className='h-full' alt="" />
              <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=85,metadata=none,w=120,h=120/app/images/products/sliding_image/409539g.jpg?ts=1706779675" className='h-full' alt="" />
              <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=85,metadata=none,w=120,h=120/app/images/products/sliding_image/409539g.jpg?ts=1706779675" className='h-full' alt="" />
              <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=85,metadata=none,w=120,h=120/app/images/products/sliding_image/409539g.jpg?ts=1706779675" className='h-full' alt="" />
              <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=85,metadata=none,w=120,h=120/app/images/products/sliding_image/409539g.jpg?ts=1706779675" className='h-full' alt="" />
              <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=85,metadata=none,w=120,h=120/app/images/products/sliding_image/409539g.jpg?ts=1706779675" className='h-full' alt="" />
              <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=85,metadata=none,w=120,h=120/app/images/products/sliding_image/409539g.jpg?ts=1706779675" className='h-full' alt="" />
              <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=85,metadata=none,w=120,h=120/app/images/products/sliding_image/409539g.jpg?ts=1706779675" className='h-full' alt="" />
            </div>
            <div className='back w-8 h-8 border absolute top-1/2 -right-4 rounded-full text-2xl md:flex hidden items-center justify-center -translate-y-1/2 bg-white shadow-[3px_3px_5px_rgba(200,200,200,.5)]'>
                <i className="ri-arrow-right-s-line"></i>
            </div>
            <div className='prev w-8 h-8 border absolute top-1/2 -left-4 rounded-full text-2xl md:flex hidden items-center justify-center -translate-y-1/2 bg-white shadow-[-3px_3px_5px_rgba(200,200,200,.5)]'>
                <i className="ri-arrow-left-s-line"></i>
            </div>
          </div>
        </div>
  )
}

export default DetailCard
