import React from 'react'
import { Link } from 'react-router-dom'

const Category = () => {
  return (
    <div className='w-full md:grid gap-2 md:grid-cols-10 flex items-center mt-5 overflow-x-auto'>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-12/paan-corner_web.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-11/Slice-2_10.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-11/Slice-3_9.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-11/Slice-5_4.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-11/Slice-7_3.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-11/Slice-16.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-11/Slice-13.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-11/Slice-11.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-11/Slice-19.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-11/Slice-20.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-11/Slice-10.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-11/Slice-7_3.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-12/paan-corner_web.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-11/Slice-19.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-11/Slice-20.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-11/Slice-10.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-11/Slice-7_3.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-12/paan-corner_web.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-11/Slice-19.png" className='w-full' alt="" />
        </Link>
        <Link to={'/cn'} className='md:w-full w-28 md:h-fit flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/layout-engine/2022-11/Slice-20.png" className='w-full' alt="" />
        </Link>
        
    </div>
  )
}

export default Category
