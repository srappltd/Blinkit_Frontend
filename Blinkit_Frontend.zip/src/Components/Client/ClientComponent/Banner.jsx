import React from 'react'

const Banner = () => {
  return (
    <div className='w-full md:grid flex items-center md:grid-cols-4 sm:grid-cols-2 grid-cols-1 overflow-x-auto gap-4 mt-5 md:px-5'>
        <div className='w-full h-[200px] rounded-md flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=720/layout-engine/2023-07/pharmacy-WEB.jpg" className='w-full h-full' alt="" />
        </div>
        <div className='w-full h-[200px] rounded-md flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=720/layout-engine/2023-07/Pet-Care_WEB.jpg" className='w-full h-full' alt="" />
        </div>
        <div className='w-full h-[200px] rounded-md flex-shrink-0'>
            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=720/layout-engine/2023-03/babycare-WEB.jpg" className='w-full h-full' alt="" />
        </div>
    </div>
  )
}

export default Banner
