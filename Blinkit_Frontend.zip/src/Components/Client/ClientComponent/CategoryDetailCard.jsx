import React from 'react'
import { Link } from 'react-router-dom'

const CategoryDetailCard = () => {
  return (
    <Link to={'/product-details'} className='card w-full pb-3 border relative rounded-md overflow-hidden flex-shrink-0'>
                <div className='h-[150px] w-full flex items-center justify-center overflow-hidden'>
                    <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/images/products/sliding_image/498984a.jpg?ts=1686566080" alt="" className='w-[80%]' />
                </div>
                <div className='discount absolute top-0 left-5'>
                    <svg width="29" height="28" viewBox="0 0 29 28" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M28.9499 0C28.3999 0 27.9361 1.44696 27.9361 2.60412V27.9718L24.5708 25.9718L21.2055 27.9718L17.8402 25.9718L14.4749 27.9718L11.1096 25.9718L7.74436 27.9718L4.37907 25.9718L1.01378 27.9718V2.6037C1.01378 1.44655 0.549931 0 0 0H28.9499Z" fill="#538CEE"></path></svg>
                    <div className='w-full pl-1 absolute cursor-pointer top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[10px] font-bold text-white leading-none'>
                        14% OFF
                    </div>
                </div>
                <div className='w-full px-3 text-[10px] font-semibold uppercase'>
                    <Link className='py-[2px] px-2 bg-slate-100 rounded-xl'>
                        <i className="ri-time-line"></i> 10 Min
                    </Link>
                </div>
                <div className='w-full px-3 py-1'>
                    <h1 className='font-semibold text-base leading-[1.2]'>Spraymintt Icymint Mouth Freshener</h1>
                    <p className='font-medium text-slate-600 mt-2 text-xs'>15 g</p>
                    <div className='w-full flex justify-between items-center mt-3 font-medium text-xs'>
                        <div className='font-bold'>
                            <h1>₹49</h1>
                            <del className='text-slate-500'>₹99</del>
                        </div>
                        <button className='w-1/2 border-2 py-2 px-3 font-bold uppercase text-green-600 rounded-md border-green-600'>Add</button>
                    </div>
                </div>
            </Link>
  )
}

export default CategoryDetailCard
