import React from "react";
import { Link } from "react-router-dom";

const NewAddress = () => {
  return (
    <div className="w-full h-full relative">
      <div className="w-full px-5 h-[12%] border-b flex items-center justify-between">
        <h1 className="font-semibold text-base text-slate-700">New Address</h1>
      </div>
      <form className="w-full h-[88%] overflow-y-auto p-4">
        <div className="w-full grid grid-cols-2 gap-5">
          <div className="w-full">
            <h1 className="font-semibold text-xs text-slate-700">Fullname</h1>
            <input
              type="text"
              placeholder="Enter Fullname"
              name="fullname"
              className="w-full text-xs mt-[2px] tracking-wider border px-3 py-[10px] outline-none border-slate-300 rounded"
            />
          </div>
          <div className="w-full">
            <h1 className="font-semibold text-xs text-slate-700">
              Mobile Number
            </h1>
            <input
              type="text"
              name="mobile"
              placeholder="Enter Mobile Number"
              className="w-full text-xs mt-[2px] tracking-wider border px-3 py-[10px] outline-none border-slate-300 rounded"
            />
          </div>
        </div>
        <div className="w-full grid grid-cols-2 gap-5 mt-2">
          <div className="w-full">
            <h1 className="font-semibold text-xs text-slate-700">Pincode</h1>
            <input
              type="text"
              name="pincode"
              placeholder="Enter Pincode"
              className="w-full text-xs mt-[2px] tracking-wider border px-3 py-[10px] outline-none border-slate-300 rounded"
            />
          </div>
          <div className="w-full">
            <h1 className="font-semibold text-xs text-slate-700">
              Current Location
            </h1>
            <input
              type="text"
              name="currentLocation"
              placeholder="Enter Current Location"
              className="w-full text-xs mt-[2px] tracking-wider border px-3 py-[10px] outline-none border-slate-300 rounded"
            />
          </div>
        </div>
        <div className="w-full grid grid-cols-1 gap-5 mt-2">
          <div className="w-full">
            <h1 className="font-semibold text-xs text-slate-700">Address</h1>
            <textarea
              type="text"
              name="address"
              placeholder="Address (Area and Street)"
              className="w-full text-xs mt-[2px] tracking-wider border px-3 py-[10px] outline-none border-slate-300 rounded"
            ></textarea>
          </div>
        </div>

        <div className="w-full grid grid-cols-2 gap-5 mt-1">
          <div className="w-full">
            <h1 className="font-semibold text-xs text-slate-700">City</h1>
            <input
              type="text"
              name="city"
              placeholder="Enter City"
              className="w-full text-xs mt-[2px] tracking-wider border px-3 py-[10px] outline-none border-slate-300 rounded"
            />
          </div>
          <div className="w-full">
            <h1 className="font-semibold text-xs text-slate-700">State</h1>
            <input
              type="text"
              placeholder="Enter State"
              name="state"
              className="w-full text-xs mt-[2px] tracking-wider border px-3 py-[10px] outline-none border-slate-300 rounded"
            />
          </div>
        </div>
        <div className="w-full grid grid-cols-2 gap-5 mt-2">
          <div className="w-full">
            <h1 className="font-semibold text-xs text-slate-700">
              Landmark (Optional)
            </h1>
            <input
              type="text"
              name="landmark"
              placeholder="Enter Landmark"
              className="w-full text-xs mt-[2px] tracking-wider border px-3 py-[10px] outline-none border-slate-300 rounded"
            />
          </div>
          <div className="w-full">
            <h1 className="font-semibold text-xs text-slate-700">
              Alternate Phone (optional)
            </h1>
            <input
              type="text"
              name="alternateMobile"
              placeholder="Enter Mobile Number"
              className="w-full text-xs mt-[2px] tracking-wider border px-3 py-[10px] outline-none border-slate-300 rounded"
            />
          </div>
        </div>

        <div className="flex items-center justify-between w-full mt-4">
          <button
            type="reset"
            className="py-2 px-10 font-medium border bg-zinc-200 rounded-sm"
          >
            Reset
          </button>
          <button
            type="submit"
            className="py-2 px-10 font-medium border bg-green-700 text-white rounded-sm"
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default NewAddress;
