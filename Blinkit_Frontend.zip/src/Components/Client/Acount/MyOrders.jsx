import React from "react";
import { Link } from "react-router-dom";

const MyOrders = () => {
  return (
    <div className="w-full h-full relative">
      <div className="w-full px-5 h-[12%] border-b flex items-center justify-between">
        <h1 className="font-semibold text-base text-slate-700">My Orders</h1>
      </div>
      <div className="w-full h-[88%]">
        <h1 className="font-semibold text-xl absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center">
          Oops, you haven't placed an order yet.
        </h1>
      </div>
    </div>
  );
};

export default MyOrders;
