import React from 'react'
import { Link } from 'react-router-dom'
import AddressCard from './AddressCard'

const MyAddress = () => {
  return (
    <div className='w-full h-full'>
        <div className='w-full px-5 h-[12%] border-b flex items-center justify-between'>
          <h1 className='font-semibold text-base text-slate-700'>My Address</h1>
          <Link to={'/account/new-address'} className='py-2 px-4 bg-green-600 text-white font-semibold rounded-sm'>Add New Address</Link>
        </div>    
        <div className='w-full h-[88%] relative p-3 overflow-y-auto'>
          <div className='flex items-center justify-center flex-col absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2'>
            <img src="https://blinkit.com/c55c5f6ddd0e42607e6c.png" alt="" />
            <h1 className='font-medium text-lg'>You have no saved addresses</h1>
            <h2 className='text-sm text-slate-400'>Tell us where you want your orders delivered</h2>

          </div>
          <div className='flex flex-col gap-3 w-full relative z-10'>
            <AddressCard/>
            <AddressCard/>
            <AddressCard/>
            <AddressCard/>
            <AddressCard/>
            <AddressCard/>
            <AddressCard/>
            <AddressCard/>
            <AddressCard/>
            <AddressCard/>
            <AddressCard/>
            <AddressCard/>
            
          </div>
        </div>
    </div>
  )
}

export default MyAddress
