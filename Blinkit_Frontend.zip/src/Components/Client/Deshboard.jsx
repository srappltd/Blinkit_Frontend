import React from 'react'
import {Outlet} from 'react-router-dom'
import HeaderBanner from './ClientComponent/HeaderBanner'
import Banner from './ClientComponent/Banner'
import Category from './ClientComponent/Category'
import CategoryCards from './ClientComponent/CategoryCards'
import Navbar from './ClientComponent/Navbar'
import Footer from './ClientComponent/Footer'
import CartBtn from './ClientComponent/CartBtn'

const Deshboard = () => {
  return (
    <>
    <Navbar/>
    <div className='w-full md:px-20 px-5'>
      <div className='w-full mt-16 pt-5'>
        <HeaderBanner/>
        <Banner/>
        <Category/>
        <CategoryCards/>
        <CategoryCards/>
        <CategoryCards/>
        <CategoryCards/>
        <CategoryCards/>
        <CategoryCards/>
        <CategoryCards/>
        <CategoryCards/>
      </div>
    </div>
    <CartBtn/>
    <Footer/>
    </>
  )
}

export default Deshboard
