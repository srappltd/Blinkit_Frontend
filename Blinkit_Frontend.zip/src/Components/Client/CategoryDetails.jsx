import React from 'react'
import { Link } from 'react-router-dom'
import CategoryDetailCard from './ClientComponent/CategoryDetailCard'
import Navbar from './ClientComponent/Navbar'
import Footer from './ClientComponent/Footer'
import CartBtn from './ClientComponent/CartBtn'

const CategoryDetails = () => {
  return (
    <>
        <Navbar/>
        <div className='w-full mt-16'>
        <div className='w-full flex overflow-x-auto md:grid fixed top-16 grid-cols-8 whitespace-nowrap md:h-10 z-40 items-center bg-white border-b md:px-20 px-5 md:shadow-[0_2px_5px_rgba(220,220,220,5)]'>
            <Link className='py-2 px-4 hover:bg-slate-100 text-slate-600 font-medium text-sm'>Vegetables & Fruits</Link>
            <Link className='py-2 px-4 hover:bg-slate-100 text-slate-600 font-medium text-sm'>Dairy & Breakfast</Link>
            <Link className='py-2 px-4 hover:bg-slate-100 text-slate-600 font-medium text-sm'>Munchies</Link>
            <Link className='py-2 px-4 hover:bg-slate-100 text-slate-600 font-medium text-sm'>Cold Drinks & Juices</Link>
            <Link className='py-2 px-4 hover:bg-slate-100 text-slate-600 font-medium text-sm'>Instant & Frozen Food</Link>
            <Link className='py-2 px-4 hover:bg-slate-100 text-slate-600 font-medium text-sm'>Bakery & Biscuits</Link>
            <Link className='py-2 px-4 hover:bg-slate-100 text-slate-600 font-medium text-sm'>Vegetables & Fruits</Link>
            <Link className='py-2 px-4 hover:bg-slate-100 text-slate-600 font-medium text-sm'>More <i className="ri-arrow-down-s-line"></i></Link>
        </div>
        <div className='w-full md:px-20 mt-24 md:flex pt-2'>
            <div className='md:w-[25%] w-full border border-slate-200 flex md:flex-col items-start overflow-y-auto md:h-[100vh]'>
                <Link className='md:py-4 py-3 px-5 border-y md:w-full w-1/2 flex-shrink-0 font-medium text-slate-700 flex items-center gap-3 relative after:w-2 md:after:h-full after:absolute after:left-0 after:top-0 after:bg-green-600'>
                    <img src="https://cdn.grofers.com/app/images/category/cms_images/icon/2380_1696572534396.png" className='w-12 h-12 rounded bg-slate-100 object-cover object-top' alt="" />
                    Biscuit Gift Pack
                </Link>
                <Link className='md:py-4 py-3 px-5 border-y md:w-full w-1/2 flex-shrink-0 font-medium text-slate-700 flex items-center gap-3 relative after:w-2 md:after:h-full after:absolute after:left-0 after:top-0 after:bg-green-600'>
                    <img src="https://cdn.grofers.com/app/images/category/cms_images/icon/953_1657599742631.png" className='w-12 h-12 rounded bg-slate-100 object-cover object-top' alt="" />
                    Biscuit Gift Pack
                </Link>
                <Link className='md:py-4 py-3 px-5 border-y md:w-full w-1/2 flex-shrink-0 font-medium text-slate-700 flex items-center gap-3 relative after:w-2 md:after:h-full after:absolute after:left-0 after:top-0 after:bg-green-600'>
                    <img src="https://cdn.grofers.com/app/images/category/cms_images/icon/28_1643445056245.png" className='w-12 h-12 rounded bg-slate-100 object-cover object-top' alt="" />
                    Biscuit Gift Pack
                </Link>
                <Link className='md:py-4 py-3 px-5 border-y md:w-full w-1/2 flex-shrink-0 font-medium text-slate-700 flex items-center gap-3 relative after:w-2 md:after:h-full after:absolute after:left-0 after:top-0 after:bg-green-600'>
                    <img src="https://cdn.grofers.com/app/images/category/cms_images/icon/105_1668515747141.png" className='w-12 h-12 rounded bg-slate-100 object-cover object-top' alt="" />
                    Biscuit Gift Pack
                </Link>
                <Link className='md:py-4 py-3 px-5 border-y md:w-full w-1/2 flex-shrink-0 font-medium text-slate-700 flex items-center gap-3 relative after:w-2 md:after:h-full after:absolute after:left-0 after:top-0 after:bg-green-600'>
                    <img src="https://cdn.grofers.com/app/images/category/cms_images/icon/209_1643445123315.png" className='w-12 h-12 rounded bg-slate-100 object-cover object-top' alt="" />
                    Biscuit Gift Pack
                </Link>
                <Link className='md:py-4 py-3 px-5 border-y md:w-full w-1/2 flex-shrink-0 font-medium text-slate-700 flex items-center gap-3 relative after:w-2 md:after:h-full after:absolute after:left-0 after:top-0 after:bg-green-600'>
                    <img src="https://cdn.grofers.com/app/images/category/cms_images/icon/938_1681720325311.png" className='w-12 h-12 rounded bg-slate-100 object-cover object-top' alt="" />
                    Biscuit Gift Pack
                </Link>
                <Link className='md:py-4 py-3 px-5 border-y md:w-full w-1/2 flex-shrink-0 font-medium text-slate-700 flex items-center gap-3 relative after:w-2 md:after:h-full after:absolute after:left-0 after:top-0 after:bg-green-600'>
                    <img src="https://cdn.grofers.com/app/images/category/cms_images/icon/107_1643445091063.png" className='w-12 h-12 rounded bg-slate-100 object-cover object-top' alt="" />
                    Biscuit Gift Pack
                </Link>
                <Link className='md:py-4 py-3 px-5 border-y md:w-full w-1/2 flex-shrink-0 font-medium text-slate-700 flex items-center gap-3 relative after:w-2 md:after:h-full after:absolute after:left-0 after:top-0 after:bg-green-600'>
                    <img src="https://cdn.grofers.com/app/images/category/cms_images/icon/1959_1687773864346.png" className='w-12 h-12 rounded bg-slate-100 object-cover object-top' alt="" />
                    Biscuit Gift Pack
                </Link>
                <Link className='md:py-4 py-3 px-5 border-y md:w-full w-1/2 flex-shrink-0 font-medium text-slate-700 flex items-center gap-3 relative after:w-2 md:after:h-full after:absolute after:left-0 after:top-0 after:bg-green-600'>
                    <img src="https://cdn.grofers.com/app/images/category/cms_images/icon/209_1643445123315.png" className='w-12 h-12 rounded bg-slate-100 object-cover object-top' alt="" />
                    Biscuit Gift Pack
                </Link>
                <Link className='md:py-4 py-3 px-5 border-y md:w-full w-1/2 flex-shrink-0 font-medium text-slate-700 flex items-center gap-3 relative after:w-2 md:after:h-full after:absolute after:left-0 after:top-0 after:bg-green-600'>
                    <img src="https://cdn.grofers.com/app/images/category/cms_images/icon/938_1681720325311.png" className='w-12 h-12 rounded bg-slate-100 object-cover object-top' alt="" />
                    Biscuit Gift Pack
                </Link>
                <Link className='md:py-4 py-3 px-5 border-y md:w-full w-1/2 flex-shrink-0 font-medium text-slate-700 flex items-center gap-3 relative after:w-2 md:after:h-full after:absolute after:left-0 after:top-0 after:bg-green-600'>
                    <img src="https://cdn.grofers.com/app/images/category/cms_images/icon/107_1643445091063.png" className='w-12 h-12 rounded bg-slate-100 object-cover object-top' alt="" />
                    Biscuit Gift Pack
                </Link>
                <Link className='md:py-4 py-3 px-5 border-y md:w-full w-1/2 flex-shrink-0 font-medium text-slate-700 flex items-center gap-3 relative after:w-2 md:after:h-full after:absolute after:left-0 after:top-0 after:bg-green-600'>
                    <img src="https://cdn.grofers.com/app/images/category/cms_images/icon/1959_1687773864346.png" className='w-12 h-12 rounded bg-slate-100 object-cover object-top' alt="" />
                    Biscuit Gift Pack
                </Link>
                <Link className='md:py-4 py-3 px-5 border-y md:w-full w-1/2 flex-shrink-0 font-medium text-slate-700 flex items-center gap-3 relative after:w-2 md:after:h-full after:absolute after:left-0 after:top-0 after:bg-green-600'>
                    <img src="https://cdn.grofers.com/app/images/category/cms_images/icon/209_1643445123315.png" className='w-12 h-12 rounded bg-slate-100 object-cover object-top' alt="" />
                    Biscuit Gift Pack
                </Link>
                <Link className='md:py-4 py-3 px-5 border-y md:w-full w-1/2 flex-shrink-0 font-medium text-slate-700 flex items-center gap-3 relative after:w-2 md:after:h-full after:absolute after:left-0 after:top-0 after:bg-green-600'>
                    <img src="https://cdn.grofers.com/app/images/category/cms_images/icon/938_1681720325311.png" className='w-12 h-12 rounded bg-slate-100 object-cover object-top' alt="" />
                    Biscuit Gift Pack
                </Link>
                <Link className='md:py-4 py-3 px-5 border-y md:w-full w-1/2 flex-shrink-0 font-medium text-slate-700 flex items-center gap-3 relative after:w-2 md:after:h-full after:absolute after:left-0 after:top-0 after:bg-green-600'>
                    <img src="https://cdn.grofers.com/app/images/category/cms_images/icon/107_1643445091063.png" className='w-12 h-12 rounded bg-slate-100 object-cover object-top' alt="" />
                    Biscuit Gift Pack
                </Link>
                <Link className='md:py-4 py-3 px-5 border-y md:w-full w-1/2 flex-shrink-0 font-medium text-slate-700 flex items-center gap-3 relative after:w-2 md:after:h-full after:absolute after:left-0 after:top-0 after:bg-green-600'>
                    <img src="https://cdn.grofers.com/app/images/category/cms_images/icon/1959_1687773864346.png" className='w-12 h-12 rounded bg-slate-100 object-cover object-top' alt="" />
                    Biscuit Gift Pack
                </Link>
                
                
                
                
            </div>
            <div className='cardbox md:w-[75%] w-full h-full'>
                <div className='w-full md:h-14 border-b flex md:flex-row flex-col gap-1 md:gap-0 md:items-center justify-between px-5 py-2 md:py-0'>
                    <h1 className='font-bold md:text-lg text-base text-slate-700'>Buy Biscuit Gift Pack Online</h1>
                    <div className='flex items-center gap-3'>
                        <span className='font-medium md:text-xs text-base text-slate-600 whitespace-nowrap'>Sort By</span>
                        <select name="" id="" className='md:py-1 py-2 md:w-fit w-full px-4 border font-medium bg-white outline-none text-green-600 border-green-700/20 rounded'>
                            <option value="">Relevance</option>
                            <option value="">Price (High to Low)</option>
                            <option value="">Price (Low to High)</option>
                            <option value="">Discount (High to Low)</option>
                            <option value="">Discount (Low to High)</option>
                            <option value="">Name (A to Z)</option>
                        </select>

                    </div>
                </div>
                <div className='w-full grid xl:grid-cols-5 lg:grid-cols-4 md:grid-cols-3 grid-cols-2 gap-4 p-3'>
                    <CategoryDetailCard/>
                    <CategoryDetailCard/>
                    <CategoryDetailCard/>
                    <CategoryDetailCard/>
                    <CategoryDetailCard/>
                    <CategoryDetailCard/>
                    <CategoryDetailCard/>
                    <CategoryDetailCard/>
                    <CategoryDetailCard/>
                    <CategoryDetailCard/>
                    <CategoryDetailCard/>
                    <CategoryDetailCard/>
                    <CategoryDetailCard/>
                    <CategoryDetailCard/>
                    <CategoryDetailCard/>
                    <CategoryDetailCard/>
                </div>
            </div>
        </div>
        </div>
        <CartBtn/>
        <Footer/>
    </>
  )
}

export default CategoryDetails
