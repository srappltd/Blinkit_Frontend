import React, { useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import Footer from './ClientComponent/Footer'
import Navbar from './ClientComponent/Navbar'

const Cart = () => {
    const [selectAddress,setSelectAddress] = useState(null)
    const selectAddressHandler = (e) =>{
        document.querySelectorAll(".selectIcon").forEach(elem=>{
            elem.classList.remove("bg-green-600")
        })
        console.log(e.target.querySelector(".selectIcon").classList.toggle('bg-green-600'))
        setSelectAddress(e.target.dataset.address)
    }
  return ( 
    <>
        <Navbar/>
        <div className='sm:w-2/5 w-full sm:px-0 px-3 m-auto mt-20'>
            <h1 className='font-semibold text-lg'>My Cart</h1>
            <div className=' mt-3 bg-sky-50 rounded-lg w-full p-3'>
                <div className='flex items-center gap-3'>
                    <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=180/assets/eta-icons/15-mins-filled.png" className='w-10 mix-blend-multiply' alt="" />
                    <div className='flex flex-col'>
                        <h1 className='font-semibold text-base leading-[1.2]'>Delivery in 8 minutes</h1>
                        <span className='text-xs font-medium text-zinc-700'>Shipment of 3 items</span>
                    </div>
                </div>
                <div className='w-full flex flex-col mt-5 gap-4'>
                    <div className='card w-full flex items-center gap-2 relative'>
                        <div className='w-16 h-16 border rounded flex items-center justify-center'>
                            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=135/app/images/products/sliding_image/432818a.jpg?ts=1688444559" className='mix-blend-multiply' alt="" />
                        </div>
                        <div className=''>
                            <h1 className='font-semibold mb-1'>Doritos Cheese Nachos</h1>
                            <span className='text-xs font-medium text-zinc-700'>60 g</span>
                            <h2 className='font-bold mt-1'>₹30</h2>
                        </div>
                        <div className='flex items-center justify-center gap-3 px-3 py-2 font-bold text-xs rounded bg-green-700 text-white absolute md:bottom-3 bottom-1 md:right-3 right-1'>
                            <i className="ri-subtract-line cursor-pointer"></i>
                            <span>2</span>
                            <i className="ri-add-fill cursor-pointer"></i>
                        </div>
                    </div>
                    <div className='card w-full flex items-center gap-2 relative'>
                        <div className='w-16 h-16 border rounded flex items-center justify-center'>
                            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=135/app/images/products/sliding_image/432818a.jpg?ts=1688444559" className='mix-blend-multiply' alt="" />
                        </div>
                        <div className=''>
                            <h1 className='font-semibold mb-1'>Doritos Cheese Nachos</h1>
                            <span className='text-xs font-medium text-zinc-700'>60 g</span>
                            <h2 className='font-bold mt-1'>₹30</h2>
                        </div>
                        <div className='flex items-center justify-center gap-3 px-3 py-2 font-bold text-xs rounded bg-green-700 text-white absolute md:bottom-3 bottom-1 md:right-3 right-1'>
                            <i className="ri-subtract-line cursor-pointer"></i>
                            <span>2</span>
                            <i className="ri-add-fill cursor-pointer"></i>
                        </div>
                    </div>
                    <div className='card w-full flex items-center gap-2 relative'>
                        <div className='w-16 h-16 border rounded flex items-center justify-center'>
                            <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=135/app/images/products/sliding_image/432818a.jpg?ts=1688444559" className='mix-blend-multiply' alt="" />
                        </div>
                        <div className=''>
                            <h1 className='font-semibold mb-1'>Doritos Cheese Nachos</h1>
                            <span className='text-xs font-medium text-zinc-700'>60 g</span>
                            <h2 className='font-bold mt-1'>₹30</h2>
                        </div>
                        <div className='flex items-center justify-center gap-3 px-3 py-2 font-bold text-xs rounded bg-green-700 text-white absolute md:bottom-3 bottom-1 md:right-3 right-1'>
                            <i className="ri-subtract-line cursor-pointer"></i>
                            <span>2</span>
                            <i className="ri-add-fill  cursor-pointer"></i>
                        </div>
                    </div>
                </div>

            </div>
            <div className=' mt-3 bg-sky-50 rounded-lg w-full p-3'>
                <h1 className='font-semibold text-base leading-[1.2]'>Bill details</h1>
                <div className='w-full mt-4 text-xs font-medium text-zinc-600'>
                    <div className='flex justify-between '>
                        <h1><i className="ri-article-fill"></i> Item total</h1>
                        <span>₹240</span>
                    </div>
                    <div className='flex justify-between mt-1'>
                        <h1><i className="ri-bike-fill"></i> Delivery charge</h1>
                        <span className='text-blue-600'><del className='text-zinc-700'>₹15</del> FREE</span>
                    </div>
                    <div className='flex justify-between mt-3 text-sm text-zinc-900'>
                        <h1><i className="ri-article-fill"></i> Grand total</h1>
                        <span>₹240</span>
                    </div>
                    
                </div>
                

            </div>
            <div className=' mt-3 bg-sky-50 rounded-lg w-full p-3'>
                <h1 className='font-semibold text-sm leading-[1.2]'>Cancellation Policy</h1>
                <p className='font-medium text-zinc-600 mt-2 text-xs'>Orders cannot be cancelled once packed for delivery. In case of unexpected delays, a refund will be provided, if applicable.</p>
            </div>
            <div className=' mt-3 bg-sky-50 rounded-lg w-full p-3'>
                <h1 className='font-semibold'>Select delivery address</h1>
                <Link to={'/account/new-address'} className='py-2 px-3 mb-1 flex items-center gap-2 bg-white rounded border mt-2 font-medium text-green-600'><i className="ri-add-large-line font-semibold"></i> Add a new address</Link>
                <span className='text-xs font-medium text-slate-600'>Your saved address</span>
                <input type="text" value={selectAddress} />
                <div className='w-full flex flex-col gap-2 mt-1'>
                    <div onClick={selectAddressHandler} data-address={'Alampur'} className='address w-full flex cursor-pointer gap-2 border p-2 rounded'>
                        <div className='w-4 h-4 overflow-hidden pointer-events-none flex-shrink-0 p-[2px] rounded-full border mt-1 border-slate-400'>
                            <div className='selectIcon w-full h-full rounded-full'></div>
                        </div>
                        <div className='w-full pointer-events-none'>
                            <h1 className='font-medium text-xs uppercase text-slate-700'>Abhay Gautam</h1>
                            <p className='text-sm tracking-wider'>ward no. 14, resthouse ke samane alampur,Block Lahar,Distt Bhind, M.P. pincode - 477449</p>
                            <Link to={'tel:6260396658'} className='text-green-600 text-xs'>+91 6260396658</Link>
                        </div>
                    </div>
                    <div onClick={selectAddressHandler} data-address={'Orai'} className='address w-full cursor-pointer flex gap-2 border p-2 rounded'>
                        <div  className='w-4 h-4 pointer-events-none overflow-hidden flex-shrink-0 p-[2px] rounded-full border mt-1 border-slate-400'>
                            <div className='selectIcon w-full h-full rounded-full'></div>
                        </div>
                        <div className='w-full pointer-events-none'>
                            <h1 className='font-medium text-xs uppercase text-slate-700'>Abhay Gautam</h1>
                            <p className='text-sm tracking-wider'>ward no. 14, resthouse ke samane alampur,Block Lahar,Distt Bhind, M.P. pincode - 477449</p>
                            <Link to={'tel:6260396658'} className='text-green-600 text-xs'>+91 6260396658</Link>
                        </div>
                    </div>
                    <div onClick={selectAddressHandler} data-address={'Bhopal'} className='address w-full cursor-pointer flex gap-2 border p-2 rounded'>
                        <div  className='w-4 h-4 pointer-events-none overflow-hidden flex-shrink-0 p-[2px] rounded-full border mt-1 border-slate-400'>
                            <div className='selectIcon w-full h-full rounded-full'></div>
                        </div>
                        <div className='w-full pointer-events-none'>
                            <h1 className='font-medium text-xs uppercase text-slate-700'>Abhay Gautam</h1>
                            <p className='text-sm tracking-wider'>ward no. 14, resthouse ke samane alampur,Block Lahar,Distt Bhind, M.P. pincode - 477449</p>
                            <Link to={'tel:6260396658'} className='text-green-600 text-xs'>+91 6260396658</Link>
                        </div>
                    </div>
                    
                </div>
            </div>
            <div className=' mt-3 bg-sky-50 rounded-lg w-full p-3'>
                <button className='py-2 px-3 w-full bg-green-600 text-white rounded flex items-center justify-between'>
                    <div className='flex flex-col'>
                        <h1 className='font-semibold text-base leading-[1.2]'>Total ₹243</h1>
                    </div>
                    <div className=' flex items-center gap-1 font-semibold text-lg'>Proceed <i className="ri-arrow-right-s-line"></i></div>
                </button>
            </div>
            
        </div>
        <Footer/>
    </>
  )
}

export default Cart
